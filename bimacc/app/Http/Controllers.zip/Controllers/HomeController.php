<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;
use Charts;
use DB;
use Carbon;
use App\models\DisputeSubcategory;
use App\models\DisputeCategory;
use App\models\notifications;
use App\models\RespondantInformation;
use Illuminate\Notifications\Notifiable;
use App\Notifications\MyFirstNotification;
use App\models\ClaimantRegister;
use Notification;
use App\DatabaseHelper;
use Auth;


class HomeController extends Controller
{
 use Notifiable;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
      $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    { 
// echo("demo");exit;
      $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null) {
        return view('auth.login');
      }
      else
      {

          $redirect = request()->i;
       $request = request();

      //echo json_encode($request) ; exit;
        echo $request->key; 

        // echo json_encode(DB::select("select * from   notifications 
        //  where latest=1 and  notifiable_id = ".auth()->user()->id)); exit;
        $Notification = DatabaseHelper::getNotificationByUserBylatest(auth()->user()->id);

        $NotificationCount = DatabaseHelper::getNotificationCountByUser(auth()->user()->id);

        $respondentcount = DB::select("select COUNT(*) claimrespondents from claimantnotice cm WHERE userid = ".auth()->user()->id);

        $total_claim_count = DB::select("select count(*) total_count from claimantnotice where claimnoticestatus !='New Claim'");
         $payadministration_fees = DB::select("select count(*) total_count_fees from claimantnotice where claimnoticestatus = 'Payment Initiated Waiting for The Payment' and userid = ".auth()->user()->id);

        $claimantRecoveryAmount = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount   from claimantnotice cn  inner join claim_details cd on (cd.claimnoticeid = cn.id)
          where cn.userid = ".auth()->user()->id);
        $allocateArbitratorcount = DB::select("select count(*) allocatedarbitrator from claimantnotice cm
          inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid =cm.id ) where cm.userid = ".auth()->user()->id);

        $claimantDashboardClaimpetioncount =DB::select("select count(*) claimantDashboardClaimpetion from claimantnotice where isstageinitiated='Y' and userid = ".auth()->user()->id);


        $claimantcurrentyearrecovery = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount from claimantnotice cn inner join claim_details cd on (cd.claimnoticeid = cn.id)
         where userid = ".auth()->user()->id." and YEAR(cd.created_at) =".date("Y"))  ;        

        $TotalAmountRecovery = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount from claimantnotice cn inner join claim_details cd on (cd.claimnoticeid = cn.id)");

        $CurrentMonthTotalAmountRecovery = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount from claimantnotice cn inner join claim_details cd on (cd.claimnoticeid = cn.id) where YEAR(cd.created_at) =".date("Y"));

        $AllocatedArbitratorCount = DB::select("select count(*) claimnoticeallocatedcount from claimantnotice cn
          inner join claimant_arbitrator_configuration cbc on cbc.claimnoticeid = cn.id where cbc.arbitrator_id = ".auth()->user()->id);

        $ClosedClaimsCountByArbitrator = DB::select("select count(*) closedclaims from claimantnotice cn
          inner join claimant_arbitrator_configuration cbc on cbc.claimnoticeid = cn.id
          where cn.claimnoticestatus='Awarded' and cbc.arbitrator_id = ".auth()->user()->id);

        $ArbitratorHelpedRecoverAmount = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount from claimantnotice cn 
          inner join claim_details cd on (cd.claimnoticeid = cn.id)
          inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid = cn.id) where cac.arbitrator_id = ".auth()->user()->id);

        $ArbitratorHelpedCurrentRecoverAmount = DB::select("select sum(Total_Outstanding_amount) Total_Outstanding_amount from claimantnotice cn 
          inner join claim_details cd on (cd.claimnoticeid = cn.id)
          inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid = cn.id) where cac.arbitrator_id = ".auth()->user()->id." and YEAR(cd.created_at) =".date("Y"));

        $RespondentAllocatedArbitrator = DB::select("select count(*) allocatedarbitrator from claimantnotice cn
          inner join respondantdetails re on re.claimnoticeid = cn.id
          inner join claimant_arbitrator_configuration cac on cac.claimnoticeid = cn.id where  re.user_id = ".auth()->user()->id);

        $ongoingarbitration = DB::select("SELECT COUNT(*) AS ongoing_arbitration FROM claimant_arbitrator_configuration cac INNER JOIN claimantnotice cm  ON (cac.claimnoticeid = cm.id AND cac.isAgreeorDisagree ='Agree')
WHERE cac.arbitrator_id = ".auth()->user()->id." AND cm.claimnoticestatus != 'Awarded'");

        $totalclaimbyarbitrator = DB::select("SELECT COUNT(*) AS total FROM claimant_arbitrator_configuration cac
INNER JOIN claimantnotice cm  ON (cac.claimnoticeid = cm.id AND cac.isAgreeorDisagree ='Agree')
WHERE cac.arbitrator_id =".auth()->user()->id);

        $counterclaimbyrespodent = DB::select("SELECT COUNT(*) respodentbycounterclaim FROM claimantnotice cm
INNER JOIN respondantdetails rd ON (rd.claimnoticeid = cm.id)
WHERE rd.user_id = ".auth()->user()->id);


        return view('home',compact('respondentcount', 'allocateArbitratorcount','claimantDashboardClaimpetioncount','claimantRecoveryAmount','claimantcurrentyearrecovery','TotalAmountRecovery','CurrentMonthTotalAmountRecovery','AllocatedArbitratorCount','ClosedClaimsCountByArbitrator','ArbitratorHelpedRecoverAmount','ArbitratorHelpedCurrentRecoverAmount','RespondentAllocatedArbitrator','Notification','NotificationCount','total_claim_count','payadministration_fees','ongoingarbitration','totalclaimbyarbitrator','counterclaimbyrespodent')); 
      }
    }

    public function doLogout()
    {
    Auth::logout(); // log the user out of our application
    return Redirect::to('login'); // redirect the user to the login screen
  }

  public function getDisputeList(Request $request, $id = null)
  {
    $disputeSubCategory = DB::table('dispute_subcategories')
    ->where('dispute_categories_id', $request->dispute_categories_id)
    ->pluck('subcategory_name','id');

    return response()->json($disputeSubCategory);
  }

  public function putDisputeList(Request $request, $id)
  {
    $disputeSubCategory = DB::table('dispute_subcategories')
    ->where('dispute_categories_id', $request->dispute_categories_id)
    ->pluck('subcategory_name','id');
    return response()->json($disputeSubCategory);  
  }


  public function sendNotification()
  {
    $user = User::first();
    $details = [
      'greeting' => 'Hello ',
      'body' => 'This is my first notification from online Arbitration',         
      'actionText' => 'View My Site',
      'actionURL' => route('claimentslist.index'),            
    ];
    $rows = $user->unreadNotifications;
    $user->notify(new MyFirstNotification($details));            
  }     
}
