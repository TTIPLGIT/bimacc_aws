<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\models\User;
use App\Role;
use Redirect;
use DB;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;



    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    } 


    // public function webLoginPost(Request $request)
    // {
    //     $this->validate($request, [
    //         'email' => 'required|email',
    //         'password' => 'required',
    //     ]);


    //     $remember_me = $request->has('remember_me') ? true : false; 


    //     if (auth()->attempt(['email' => $request->input('email'), 'password' => $request->input('password')], $remember_me))
    //     {
    //         $user = auth()->user();
    //         return Redirect::to('home/index');
    //        // dd($user);
    //     }else{
    //         return back()->with('error','your username and password are wrong.');
    //     }
    // }  

    public function showLoginForm()  
    {
        $allroles = DB::select("select * from roles ORDER BY display_name ASC");

        return view('auth.login',compact('allroles'));
    }


     protected function credentials(Request $request)
    {
        //echo $request;exit;

        if(is_numeric($request->get('email'))){
            return ['phone'=>$request->get('email'),'password'=>$request->get('password'),'roles_id'=>$request->get('role_id')];
        }

        return $request->only($this->username(), 'password','roles_id');
    }

    
// public function logout()
// {
//      session(['user' => null]); 
//        return view('auth/login');
// }

}
