<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\models\User;
use App\models\ArbitrationMaster;
use App\models\DisputeCategory;
use App\models\DisputeSubcategory;
use App\Role;
use App\ClaimantRegister;
use Auth;
use Validator;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;
use DB;
use Redirect;
use \Crypt;
use App\DatabaseHelper;


class ArbitrationMasterController extends Controller
{
    use RegistersUsers;


     /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
     protected function validator(array $data)
     {
        return Validator::make($data, [
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:20',
            'email' => 'required|string|email|max:255|unique:users'            
        ]);

    }
    

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id = null)
    {
         $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null)
      {

        return view('auth.login');
      }

        $arbitrationmasters = DatabaseHelper::getarbitratormaster_index();
        $claimnotice = DB::select("select distinct sm.claimnoticeno,cpa.arbitration_petionno,sm.claimnoticestatus,date_format(sm.created_at,'%d-%m-%Y %H:%i:%s') created_at,cf.claim_amount,sm.id,sm.userid,
        cf.dispute_categories_id,cf.dispute_subcategories_id,dc.category_name,dcp.subcategory_name, CONCAT(am.firstname,' ' , am.lastname) AS arbitrator_name,am.arbitrator_code,(SELECT arbitrator_fees FROM arbitrator_allocation_fees 
        where cd.claimamount between claim_amount_form and claim_amount_to) AS arbitrator_fees,cd.claimamount,
        (SELECT adminstration_fees FROM arbitrator_allocation_fees 
        where cd.claimamount between claim_amount_form and claim_amount_to) AS adminstration_fees from claimantnotice sm
        inner join claim_fees cf on (cf.claimnoticeid =sm.id )
        inner join claimant_informations ci on (ci.claimnoticeid =sm.id )
        left join claim_details cd on (cd.claimnoticeid =sm.id and cd.is_respondant is null )

        inner join dispute_categories dc on (ci.dispute_categories_id = dc.id)
        inner join dispute_subcategories dcp on (dcp.id = ci.dispute_subcategories_id)
        inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid = sm.id)
         inner join claimnotice_petion_arbitrationno cpa on (cpa.claimnoticeid = sm.id)
        LEFT JOIN arbitration_masters am ON (am.user_id = cac.arbitrator_id)
        where cac.arbitrator_id= ".$user_id. " order by sm.id desc");

        // echo json_encode($arbitrationmasters); exit;
        // $arbitrationmasters = ArbitrationMaster::all();
        
        $arbitrationcount = count($arbitrationmasters);

        $disputecategory = DisputeCategory::all();
        
        $disputesubcategory = DisputeSubcategory::all();

        
        $dispute_categories = DB::table('dispute_categories')->get();
        $dispute_subcategories = DB::table('dispute_subcategories')->get();

        return view('arbitrationmaster.index', compact('arbitrationmasters','disputecategory','disputesubcategory', 'dispute_categories','dispute_subcategories', 'arbitrationcount','claimnotice'));
    }

public function arbitratorindex($id)
    {
        

        
        $claimnotice = DB::select("select distinct sm.claimnoticeno,cpa.arbitration_petionno,sm.claimnoticestatus,date_format(sm.created_at,'%d-%m-%Y %H:%i:%s') created_at,cf.claim_amount,sm.id,sm.userid,
        cf.dispute_categories_id,cf.dispute_subcategories_id,dc.category_name,dcp.subcategory_name, CONCAT(am.firstname,' ' , am.lastname) AS arbitrator_name,am.arbitrator_code,(SELECT arbitrator_fees FROM arbitrator_allocation_fees 
        where cd.claimamount between claim_amount_form and claim_amount_to) AS arbitrator_fees,cd.claimamount,
        (SELECT adminstration_fees FROM arbitrator_allocation_fees 
        where cd.claimamount between claim_amount_form and claim_amount_to) AS adminstration_fees from claimantnotice sm
        inner join claim_fees cf on (cf.claimnoticeid =sm.id )
        inner join claimant_informations ci on (ci.claimnoticeid =sm.id )
        left join claim_details cd on (cd.claimnoticeid =sm.id and cd.is_respondant is null )

        inner join dispute_categories dc on (ci.dispute_categories_id = dc.id)
        inner join dispute_subcategories dcp on (dcp.id = ci.dispute_subcategories_id)
        inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid = sm.id)
         inner join claimnotice_petion_arbitrationno cpa on (cpa.claimnoticeid = sm.id)
        LEFT JOIN arbitration_masters am ON (am.user_id = cac.arbitrator_id)
        where cac.arbitrator_id= ".$id. " order by sm.id desc");

        // echo json_encode($arbitrationmasters); exit;
        // $arbitrationmasters = ArbitrationMaster::all();
        
       

        return view('arbitrationmaster.arbitratorcase', compact('claimnotice'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   

        return view('arbitrationmaster.create');      
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id = null)
    {
        //$existingmail = DB::select("SELECT * FROM users WHERE email='".$request->email."'  and roles_id in (3)"); 


        $this->validate($request, [
            'firstname' => 'required',
            'lastname' =>'required',
            'arbitrator_code'=>'regex:/^[\w-]*$/',
            'email' => 'required|email',
            'phone' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10|max:15',
            'country' => 'required',
            'city' => 'required',
            'state' => 'required',
            
        ]);

        $existingmail = DB::select("SELECT * FROM users WHERE email='".$request->email."'  and roles_id in (3)"); 


        $countdetails = count($existingmail);

        if($countdetails == 1){
            return redirect()->route('arbitrationmaster.index')
       ->with('success','Email id already exist.');
        }


else{
        $roles = Role::where('name', 'arbitrator')->first();

        // $pw = User::generatePassword();
        $password_string = 'abcdefghijklmnpqrstuwxyzABCDEFGHJKLMNPQRSTUWXYZ23456789';
        $password = substr(str_shuffle($password_string), 0, 8);
        $encrypt = Crypt::encrypt($password); 
       
        // echo json_encode($decrypt);exit;     
        $user = new User();
        $fullname =   $request->firstname.' '.$request->lastname;      
        $user->name = $fullname;
        $user->username = $fullname;
        $user->email = $request->email;
        $user->password = $password;
        $user->roles()->associate($roles);
        $user->encrypt_pass =$encrypt;
        // $decrypt_password=Crypt::decrypt($user->encrypt_pass);

        
        // echo json_encode( $user->decrypt_pass);exit;
        $usertype = $roles;        
        $user->usertype = $usertype;       
        $user->save();
        $user->id; 
         $decrypt = Crypt::decrypt($encrypt);
         $data = array(
     
      'decrypt' =>$decrypt, 
    );


        User::sendWelcomeEmail($user,$data); 
        
        $arbitrationmaster = new ArbitrationMaster();
        $user_id = $user->id;               
        
        $arbitrationmaster->firstname = $request->firstname;        
        $arbitrationmaster->lastname = $request->lastname;
        $fullname = $arbitrationmaster->firstname." ".$arbitrationmaster->lastname;
        $arbitrationmaster->username = $fullname;
        $arbitrationmaster->email = $request->email;              
        $arbitrationmaster->phone = $request->phone;
        $arbitrationmaster->alt_phone = $request->alt_phone;        
        $arbitrationmaster->city = $request->city;
        $arbitrationmaster->state = $request->state;
        $arbitrationmaster->country = $request->country;
        $arbitrationmaster->zipcode = $request->zipcode;
        $arbitrationmaster->address = $request->address;               
        $arbitrationmaster->usertype = $usertype;
        $arbitrationmaster->dispute_categories_id = $request->dispute_categories_id;
        $arbitrationmaster->dispute_subcategories_id = $request->dispute_subcategories_id;
        $arbitrationmaster->arbitrator_code = $request->arbitrator_code;
        $arbitrationmaster->user_id = $user_id;
        $arbitrationmaster->roles()->associate($roles);
        $usertype = $roles;        
        $arbitrationmaster->usertype = $usertype;                          
        
        
        if ($arbitrationmaster->save()) 
        {

            $phone = $arbitrationmaster->phone;


            $url="https://www.way2sms.com/api/v1/sendCampaign";
$message = urlencode("Welcome to the Online Arbitration System. Thank You for Registering As a Arbitrator Check Your Email For Login Credential.");// urlencode your message
$curl = curl_init();
curl_setopt($curl, CURLOPT_POST, 1);// set post data to true
curl_setopt($curl, CURLOPT_POSTFIELDS, "apikey=9NTU6RCILNPNZWF5MYHMK7O9TA0W9OZB&secret=REL8EGNQQK3XCEE3&usetype=stage&phone=$phone&senderid=$user_id&message=$message");
// post data
// query parameter values must be given without squarebrackets.
 // Optional Authentication:
curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($curl);
curl_close($curl);
echo $result;




           // Redirect to the new accessory  page
return redirect()->route('arbitrationmaster.index')
->with('success','Arbitration Master Created successfully.');
}

return redirect()->back()->withInput()->withErrors($arbitrationmaster->getErrors());   
}
}

    /**
     * Display the specified resource.
     *
     * @param  \App\DisputeCategory  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      //   echo "good";exit;
      //  $user_id = (auth()->check()) ? auth()->user()->id : null;

      // if ( $user_id==null)
      // {

      //   return view('auth.login');
      // }
        $arbitrationmasters = ArbitrationMaster::findOrFail($id);
        return view('arbitrationmaster.show', compact('arbitrationmasters'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DisputeCategory  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {        
       
        $arbitrationmasters = ArbitrationMaster::find($id);

        $dispute_categories = DisputeCategory::all();
        $dispute_subcategories = DisputeSubcategory::all();                    

        return view('arbitrationmaster.edit', compact('arbitrationmasters','dispute_categories','dispute_subcategories', $arbitrationmaster));         
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DisputeCategory  $dispute
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id = null)
    {
        // $request->validate([
        //     'firstname' => 'required',
        //     'username' => 'required',
        // ]);

        //echo $id; exit;
      ArbitrationMaster::findOrFail($id)->update($request->all());
        return redirect()->route('arbitrationmaster.index')
        ->with('success','Arbitration Master updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DisputeCategory  $disputeCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      //echo $id; exit;
        $arbitrationmasters = ArbitrationMaster::find($id);
        $arbitrationmasters->delete();
        return redirect()->route('arbitrationmaster.index')
        ->with('success','Arbitration Master deleted successfully.');
    }  



}
