<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\ClaimantInformation;
use App\models\RespondantInformation;
use App\models\ClaimDetails;
use App\models\ClaimNotice;
use App\models\ReliefRequest;
use App\models\DisputeCategory;
use App\models\DisputeSubcategory;
use App\models\ClaimantNoticeStatus;
use App\models\ArbitrationMaster;
use App\models\paymentdetails;
use App\models\notifications;
use DB;
use Session;
use Auth;
use App\models\User;
use Role;
use Dompdf\dompdf;
use Redirect;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;
use App\AlfrescoDocument;
use App\DatabaseHelper;

class ReportController  extends Controller
{
	 
      public function noticereport()
    {  
      //echo "jhjh";exit;
      $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null)
      {

        return view('auth.login');
      }
      $rows = DB::select("select distinct sm.respondant_status, sm.claimnoticeno,ci.firstname AS username,pet.arbitration_petionno,TRIM(sm.claimnoticestatus) as claimnoticestatus,sm.userid,date_format(sm.created_at,'%d-%m-%Y %H:%i:%s') created_at,cf.claim_amount,sm.id,sm.awardedstatement,isstageinitiated,
    cf.dispute_categories_id,cf.dispute_subcategories_id,dc.category_name,dcp.subcategory_name,(SELECT arbitrator_fees FROM arbitrator_allocation_fees 
    where cd.damage_with_interest between claim_amount_form and claim_amount_to) AS arbitrator_fees,cd.damage_with_interest,
    (SELECT adminstration_fees FROM arbitrator_allocation_fees 
    where cd.damage_with_interest between claim_amount_form and claim_amount_to) AS adminstration_fees from claimantnotice sm
    left join claim_fees cf on (cf.claimnoticeid =sm.id )
    left join claimant_informations ci on (ci.claimnoticeid =sm.id )
    
    left join dispute_categories dc on (ci.dispute_categories_id = dc.id)
    left join relief_request cd on (cd.claimnoticeid = sm.id)
    left join dispute_subcategories dcp on (dcp.id = ci.dispute_subcategories_id)
    left join claimnotice_petion_arbitrationno pet on (pet.claimnoticeid = sm.id)
    where cd.is_respondant is null  order by sm.id desc");
      return view('Reports.notice_list', compact('rows'));
     }
      public function petitionreport()
    {  
      //echo "jhjh";exit;
      $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null)
      {

        return view('auth.login');
      }
      $rows = DB::select("select distinct sm.claimnoticeno,ci.firstname AS username,sm.claimnoticestatus,date_format(sm.created_at,'%d-%m-%Y %H:%i:%s') created_at,cf.claim_amount,sm.id,sm.userid,
        cf.dispute_categories_id,cf.dispute_subcategories_id,dc.category_name,dcp.subcategory_name,pet.arbitration_petionno from claimantnotice sm
        inner join claim_fees cf on (cf.claimnoticeid =sm.id )
        inner join claimant_informations ci on (ci.claimnoticeid =sm.id )
        inner join dispute_categories dc on (ci.dispute_categories_id = dc.id)
        inner join dispute_subcategories dcp on (dcp.id = ci.dispute_subcategories_id)
        inner join claimant_arbitrator_configuration cac on (cac.claimnoticeid = sm.id)
        left join claimnotice_petion_arbitrationno pet on (pet.claimnoticeid = sm.id)
        where sm.isstageinitiated ='Y'");
      return view('Reports.petition_list', compact('rows'));
     }
     public function hearingreport()
    {  
      //echo "jhjh";exit;
      $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null)
      {

        return view('auth.login');
      }
      $rows = DB::select("SELECT cm.claimnoticeno,hm.hearing_number,rf.name AS role_name,usf.name AS from_name, (CASE when hm.message_type ='Public' then 'All' ELSE usto.name END) AS to_name,hm.message_text,hm.message_read FROM hearing_messages hm
INNER JOIN claimantnotice cm ON (cm.id = hm.claim_id)
LEFT JOIN users usf ON (usf.id = hm.from_user_id)
LEFT JOIN roles rf ON (rf.id = usf.roles_id)
LEFT JOIN users usto ON (usto.id = hm.to_user_id)
ORDER BY cm.id desc");
      return view('Reports.hearing_list', compact('rows'));
     }
     public function videoreport()
    {  
      //echo "jhjh";exit;
      $user_id = (auth()->check()) ? auth()->user()->id : null;
      if ( $user_id==null)
      {

        return view('auth.login');
      }
      $videoconferencing = DatabaseHelper::getvideo_conference();
      return view('Reports.videoconference_report', compact('videoconferencing'));
     }


	}